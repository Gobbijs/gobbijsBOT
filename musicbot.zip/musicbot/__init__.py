from .bot import MusicBot

__all__ = ['MusicBot']
